def bob_measure_qubit(bob_bases, qubit_index, qubit_circuit):
    ## WRITE YOUR CODE HERE
    pass
    ## WRITE YOUR CODE HERE